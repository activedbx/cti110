# 7.16 LAB: Input: Welcome message.

user_name = input()
# username input value pulled from value box

print('Hello', user_name, "and welcome to CS Online!")
# prints output "Hello Pat and Welcome to CS Online!"
